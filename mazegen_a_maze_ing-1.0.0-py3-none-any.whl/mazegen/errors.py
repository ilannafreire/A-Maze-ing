"""Exceptions shared by maze generation components."""


class MazeGenerationError(ValueError):
    """Raised when a maze cannot satisfy its requested constraints."""